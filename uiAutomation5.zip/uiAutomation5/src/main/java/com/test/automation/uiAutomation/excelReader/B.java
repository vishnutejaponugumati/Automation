package com.test.automation.uiAutomation.excelReader;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class B extends A{
private boolean rt() {
	// TODO Auto-generated method stub
		try {
			return true;
		} catch (Exception e){
			//ignore
		}
		return false;

}
private void vt() {
	// TODO Auto-generated method stub
boolean rvt = rt();
System.out.println(rvt);
}
public static void main(String[] args) {
	A a = new A();
	A b = new A();
	A c = new B();
	B d = new B();
	d.vt();
}
}
