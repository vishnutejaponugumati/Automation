package com.test.automation.uiAutomation.homepage;

import java.io.IOException;
import java.net.URL;
import java.util.Random;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.test.automation.uiAutomation.excelReader.ExcelUtils;
import com.test.automation.uiAutomation.testBase.Testbase;
import com.test.automation.uiAutomation.uiActions.Homepage;

@Listeners(com.test.automation.uiAutomation.testBase.ListenerTest.class)
public class TC001_Verifyloginwithinvalid_details2 extends Testbase {
	ExcelUtils excel_Reader;
	public static String FilePath ="src/main/java/com/test/automation/uiAutomation/data/TestData.xlsx";
	public static String SheetName = "RegistrationTestData";
	WebDriver driver;
	@FindBy(xpath="//A[@class='login']")
	WebElement signin;
	
	
	@Test
	public void Verifyloginwithinvalid_details() throws Exception {
		DesiredCapabilities caps = new DesiredCapabilities();
	    caps.setCapability("browser", "Chrome");
	caps.setCapability("browser_version", "69.0");
	caps.setCapability("os", "Windows");
	caps.setCapability("os_version", "10");
	caps.setCapability("resolution", "1024x768");
	caps.setCapability("name", "Bstack-[Java] Sample Test");

	    WebDriver driver = new RemoteWebDriver(new URL(URL), caps);
	  driver.get("http://automationpractice.com/index.php");
	  Thread.sleep(3000);
		// TODO Auto-generated method stub
	    	//signin.click();
	    	driver.findElement(By.xpath("//A[@class='login']")).click();
			//excel_Reader.setExcelFile(FilePath.toString(), SheetName.toString());
	    	ExcelUtils.setExcelFile(FilePath.toString(), SheetName.toString());
			Random rand = new Random();
			int randnum = rand.nextInt(10000000);
			String email = "testmail"+randnum+"@gt.com";
			System.out.println(email);
			
			 String firstname="teja";
			 String lastname="Reddy";
			 String Password="pwd123";
			 String Company= "Nendrasys";
			 String Address1= "Yousufguda";
			 String City= "Hyderabad";
			 String Postalcode= "500045";
			 String Mobile="7416602259";
				
		 driver.findElement(By.xpath("//INPUT[@id='email_create']")).sendKeys(email);
			driver.findElement(By.xpath("xpathExpression")).click();
			driver.findElement(By.xpath("//*[@id='id_gender1']")).click();
			 driver.findElement(By.xpath("//INPUT[@id='customer_firstname']")).sendKeys(firstname);
			 driver.findElement(By.xpath("//INPUT[@id='customer_lastname']")).sendKeys(lastname);
			 driver.findElement(By.xpath("//*[@id='passwd']")).sendKeys(Password);

			Select Day = new Select(driver.findElement(By.xpath("//*[@id='days']")));
			Day.selectByIndex(5);
			Select Month = new Select(driver.findElement(By.xpath("//*[@id='months']")));
			Month.selectByIndex(5);
			Select Year = new Select(driver.findElement(By.xpath("//*[@id='years']")));
			 driver.findElement(By.xpath("//*[@id='years']")).sendKeys("1993");
			 driver.findElement(By.xpath("//*[@id='company']")).sendKeys(Company);

			 driver.findElement(By.xpath("xpathExpression")).sendKeys(Address1);

			 driver.findElement(By.xpath("//*[@id='city']")).sendKeys(City);

			Select State = new Select(driver.findElement(By.xpath("//*[@id='state']")));
			State.selectByIndex(5);
			 driver.findElement(By.xpath("//*[@name='postcode']")).sendKeys(Postalcode);
			 driver.findElement(By.xpath("//*[@id='phone_mobile']")).sendKeys(Mobile);
			driver.findElement(By.xpath("//*[@id='submitAccount']")).click();
System.out.println("Success");			
	    	
	}
		/*
	@AfterTest
	public void getScreenshot() {
		// TODO Auto-generated method stub
		log.info("Test Completed Successfully");
	}
*/}
