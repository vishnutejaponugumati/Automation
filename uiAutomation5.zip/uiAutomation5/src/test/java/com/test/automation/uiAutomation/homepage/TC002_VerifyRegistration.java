package com.test.automation.uiAutomation.homepage;

import java.io.IOException;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.test.automation.uiAutomation.testBase.Testbase;
import com.test.automation.uiAutomation.uiActions.Registration;
@Listeners(com.test.automation.uiAutomation.testBase.ListenerTest.class)

public class TC002_VerifyRegistration extends Testbase {
		
	Registration registration;
	public static final Logger log = Logger.getLogger(TC002_VerifyRegistration.class.getName());
	
	@BeforeTest
	public void setUp() throws IOException  {

		// TODO Auto-generated method stub
		init();

	}

	@Test(priority=1)
	public void verifyRegistration() throws Exception {
		
			log.info("=======started verifyRegistration Test===========");
			registration = new Registration(driver);
			registration.tegistrationToApplication();
			//registration.getLoginUserName();
	    	log.info("Register with new user Successfully");

	}
	
	@AfterTest
	public void getScreenshot() {
		// TODO Auto-generated method stub
		String success = registration.getLoginUserName();
    	getScreenShot(success);
	}
	
}
