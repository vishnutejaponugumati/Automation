package com.test.automation.uiAutomation.homepage;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.test.automation.uiAutomation.excelReader.ExcelUtils;
import com.test.automation.uiAutomation.testBase.Testbase;
import com.test.automation.uiAutomation.uiActions.Homepage;
import com.test.automation.uiAutomation.uiActions.Login;

@Listeners(com.test.automation.uiAutomation.testBase.ListenerTest.class)
public class TC003_Verifyloginwithvalid_details extends Testbase {
	
	//Login login;
	Testbase testbase;
	ExcelUtils excelUtils;
	Homepage homepage;

	private int iTestCaseRow;
	@BeforeTest
	public void setUp() throws Exception {
	// TODO Auto-generated method stub
		init();
}
	
	@Test
	public void Verifyloginwithvalid_details() throws Exception {
		// TODO Auto-generated method stub
		homepage =  new Homepage(driver);
	    	log.info("Before enter username and password");

	    	homepage.loginWithvalid();
	    	log.info("After given username and password");
	    	Assert.assertEquals(homepage.getloginUserName(), "rahul kumar");
	    	//String error = homepage.getInvalidLoginText();
	    	//getScreenShot(error);
	    	String success = homepage.getloginUserName();
	    	getScreenShot(success);
	    	
	}
	
	/*@DataProvider
	 
	 public Object[][] Authentication() throws Exception{
		 
		ExcelUtils.setExcelFile("src/main/java/com/test/automation/uiAutomation/data/TestData.xlsx","LoginTestData");
 	    Object[][] testObjArray = (Object[][]) ExcelUtils.getTableArray("src/main/java/com/test/automation/uiAutomation/data/TestData.xlsx","LoginTestData");
 
	    	return (testObjArray);
		}*/
	@AfterTest
	public void getScreenshot() {
		// TODO Auto-generated method stub
		log.info("Test Completed Successfully");
	}
}
