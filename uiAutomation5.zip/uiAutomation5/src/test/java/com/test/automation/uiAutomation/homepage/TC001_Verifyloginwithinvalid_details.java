package com.test.automation.uiAutomation.homepage;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.test.automation.uiAutomation.testBase.Testbase;
import com.test.automation.uiAutomation.uiActions.Homepage;

@Listeners(com.test.automation.uiAutomation.testBase.ListenerTest.class)
public class TC001_Verifyloginwithinvalid_details extends Testbase {
	
	Homepage homepage;
	Testbase testbase;


	@BeforeTest
	public void setUp() throws Exception {
	// TODO Auto-generated method stub
		init();
}
	
	@Test
	public void Verifyloginwithinvalid_details() throws Exception {
		// TODO Auto-generated method stub
	    	homepage =  new Homepage(driver);
	    	log.info("Before enter username and password");
	    	homepage.loginWithInvalid();
	    	
	    	
	    	log.info("After given username and password");
	    	Assert.assertEquals(homepage.getInvalidLoginText(), "Authentication failed.");
	    	//String error = homepage.getInvalidLoginText();
	    	//getScreenShot(error);
	    	String success = homepage.getInvalidLoginText();
	    	
	    	getScreenShot(success);
	}
		
	@AfterTest
	public void getScreenshot() {
		// TODO Auto-generated method stub
		log.info("Test Completed Successfully");
	}
}
