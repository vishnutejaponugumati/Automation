package test;

public class A {
public static void main(String[] args) {
	A3 a = new A2();
	a.m1();
	
}
}
