package test;

public class A2 implements A3{
public void m4() {
	// TODO Auto-generated method stub
	System.out.println("i am m4");

}
public void m5() {
	// TODO Auto-generated method stub
	System.out.println("i am m5");

}
public void m1() {
	// TODO Auto-generated method stub
	
}
public void m2() {
	// TODO Auto-generated method stub
	
}
public void m3() {
	// TODO Auto-generated method stub
	
}
}
