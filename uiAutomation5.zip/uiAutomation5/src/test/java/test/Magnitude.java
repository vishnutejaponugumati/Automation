package test;

import java.util.Scanner;
public class Magnitude {
		
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int size = Integer.parseInt(sc.nextLine());
	String[] s = new String[size];
	for (int i = 0; i < size; i++) {
		s[i]=sc.nextLine();
		
	}
	
	for (int i = 0; i < size; i++) {
		System.out.println(s[i].length());
		
	}
}
}
