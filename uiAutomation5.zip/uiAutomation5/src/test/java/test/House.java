package test;
import java.util.Scanner;
public class House {
	public static char And1(char s1, char s2) {
		if(s1=='?'||s2=='?') {
			return '?';
			
		}
		else if(s1=='0'||s2=='0') {
			return '0';
			
		}
		else 
			return '1';
		
				
	}
	public static char Or1(char s1, char s2) {
		if(s1=='1'||s2=='1') {
			return '1';
			
		}
		else if(s1=='0'&&s2=='0') {
			return '0';
			
		}
		else 
			return '?';
		
				
	}
	public static char[] getdefault() {
		return new char[]{'?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?'};	
	}
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int size = Integer.parseInt(sc.nextLine());
	while(size !=0) {
	String[] s = new String[size];
	char[] local=getdefault();
	for (int i = 0; i < size; i++) {
		s[i]=sc.nextLine();	
	}
	//System.out.println();
	for (int i = 0; i < size; i++) {
		if(s[i].contains("SET")) {
			String[] temps=s[i].split(" ");
			local[31-Integer.valueOf(temps[1])]='1';
		}
		else if(s[i].contains("CLEAR")) {
			String[] temps=s[i].split(" ");
			local[31-Integer.valueOf(temps[1])]='0';
		}
		else if(s[i].contains("AND")) {
			String[] temps=s[i].split(" ");
			local[31-Integer.valueOf(temps[1])]=And1(local[31-Integer.valueOf(temps[1])],local[31-Integer.valueOf(temps[2])]);
		}
		else if(s[i].contains("OR")) {
			String[] temps=s[i].split(" ");
			local[31-Integer.valueOf(temps[1])]=Or1(local[31-Integer.valueOf(temps[1])],local[31-Integer.valueOf(temps[2])]);
		}
	}
	for(Character c:local) {
		System.out.print(c);
	}
	size = Integer.parseInt(sc.nextLine());
	
	}
	sc.close();
}
}
