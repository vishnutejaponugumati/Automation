package test;

interface A3 {
void m1();
void m2();
void m3();
}
